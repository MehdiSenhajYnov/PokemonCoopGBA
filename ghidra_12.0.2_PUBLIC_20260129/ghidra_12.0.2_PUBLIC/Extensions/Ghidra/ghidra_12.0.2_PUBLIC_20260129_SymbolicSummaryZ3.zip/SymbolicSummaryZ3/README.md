# Symbolic Summary Z3 Module

This module is shipped with the pre-built Z3 version 4.13.0 libraries and java bindings from [the Z3Prover repository](https://github.com/Z3Prover/z3).
If the native components are not suitably linked for your system, you may need to build from source.
If so, download the source bundle and follow the instructions for building it on your platform.
